import boto3
import os


def send_files_to_aws(client_s3, file, location):
    """ Accepts file and uploads to aws s3. """
    try:
        client_s3.put_object(
            Body=file,
            Bucket="image-time-capsule",
            Key=location,
            ContentType= file.mimetype
            )
    except Exception as e:
        print("Exception caught while sending files to aws", e)
        return e
    return "{}{}".format(location, str(file.filename))

